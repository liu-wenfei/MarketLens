from __future__ import annotations

from dataclasses import dataclass
import json

import pytest

from marketlens.human.portfolio.preview import PortfolioAction
from marketlens.validation.account_capacity import (
    AccountProfile,
    TradeIntent,
    ValidationConfig,
    boundary_search,
    build_initial_account,
    canonical_price_matrix,
    generate_monte_carlo_intents,
    run_deterministic_path,
)


ASSETS = ("CGEI", "CPEI", "EREI", "FSEI", "IEEI", "MEI", "REEI", "TLEI", "TSEI", "TTEI")
DATES = (
    "2023-06-19", "2023-06-20", "2023-06-21", "2023-06-26", "2023-06-27",
    "2023-06-28", "2023-06-29", "2023-06-30", "2023-07-03", "2023-07-04",
    "2023-07-05", "2023-07-06", "2023-07-07", "2023-07-10", "2023-07-11",
)


@dataclass(frozen=True)
class Close:
    close: float


class FakeProvider:
    def get_close(self, stock_id: str, date: str) -> Close:
        asset_offset = ASSETS.index(stock_id) * 0.25
        day_offset = DATES.index(date) * 0.10
        return Close(10.0 + asset_offset + day_offset)


def config(profile: AccountProfile) -> ValidationConfig:
    return ValidationConfig(
        total_wealth=profile.total_wealth,
        target_stock_id="MEI",
        asset_ids=ASSETS,
        period_dates=DATES,
        critical_periods=frozenset({1, 8, 15}),
        family_id="test-family",
        family_description="test",
        profiles=(profile,),
    )


def profile(cash_fraction: float = 0.35) -> AccountProfile:
    weight = (1.0 - cash_fraction) / len(ASSETS)
    return AccountProfile(
        profile_id="test-profile",
        total_wealth=1_000_000.0,
        cash_fraction=cash_fraction,
        initial_weights={asset: weight for asset in ASSETS},
        max_position_weight=0.13,
        transaction_cost_bps=10.0,
    )


def test_initial_account_preserves_total_wealth_and_rounding_remainder_as_cash():
    p = profile(0.35)
    prices = canonical_price_matrix(FakeProvider(), asset_ids=ASSETS, period_dates=DATES)[DATES[0]]
    account, realized = build_initial_account(p, prices)
    assert account.total_value(prices) == pytest.approx(1_000_000.0, abs=0.02)
    assert account.cash / p.total_wealth >= 0.35
    assert set(account.positions) == set(ASSETS)
    assert sum(realized.values()) <= 0.65


def test_same_period_multiple_assets_are_supported_by_validation_path():
    p = profile(0.35)
    cfg = config(p)
    matrix = canonical_price_matrix(FakeProvider(), asset_ids=ASSETS, period_dates=DATES)
    intents = (
        TradeIntent(1, "MEI", PortfolioAction.BUY, 0.01, "first"),
        TradeIntent(1, "FSEI", PortfolioAction.BUY, 0.01, "second"),
    )
    summary, rows = run_deterministic_path(
        profile=p,
        episode_id="e-test",
        price_matrix=matrix,
        config=cfg,
        path_id="multi",
        intents=intents,
    )
    assert [row["stock_id"] for row in rows] == ["MEI", "FSEI"]
    assert all(row["period_number"] == 1 for row in rows)
    assert summary["orders_requested"] == 2
    assert summary["orders_executed"] == 2


def test_invalid_order_is_recorded_without_silent_clamping():
    p = profile(0.25)
    cfg = config(p)
    matrix = canonical_price_matrix(FakeProvider(), asset_ids=ASSETS, period_dates=DATES)
    intents = (TradeIntent(1, "MEI", PortfolioAction.BUY, 0.50, "oversized"),)
    summary, rows = run_deterministic_path(
        profile=p,
        episode_id="e-test",
        price_matrix=matrix,
        config=cfg,
        path_id="invalid",
        intents=intents,
    )
    assert summary["invalid_orders"] == 1
    assert rows[0]["valid"] is False
    assert rows[0]["executed_notional"] == 0.0
    assert rows[0]["reason_code"] in {"POSITION_LIMIT", "INSUFFICIENT_CASH"}


def test_boundary_search_uses_sequential_engine_capacity_and_reports_symmetry():
    p = profile(0.35)
    cfg = config(p)
    matrix = canonical_price_matrix(FakeProvider(), asset_ids=ASSETS, period_dates=DATES)
    rows = boundary_search(
        profile=p,
        episode_id="e-test",
        first_prices=matrix[DATES[0]],
        config=cfg,
    )
    assert len(rows) == 4
    assert all(row["upward_capacity_fraction"] >= 0.0 for row in rows)
    assert all(row["downward_capacity_fraction"] > 0.0 for row in rows)
    assert all(row["directional_asymmetry_abs_fraction"] >= 0.0 for row in rows)


def test_monte_carlo_stress_inputs_are_seed_reproducible():
    p = profile()
    cfg = config(p)
    first = generate_monte_carlo_intents(config=cfg, n_paths=5, seed=123)
    second = generate_monte_carlo_intents(config=cfg, n_paths=5, seed=123)
    assert first == second
    assert first != generate_monte_carlo_intents(config=cfg, n_paths=5, seed=124)
