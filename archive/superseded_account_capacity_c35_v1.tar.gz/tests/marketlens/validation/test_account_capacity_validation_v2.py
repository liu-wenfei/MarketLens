from __future__ import annotations

from dataclasses import dataclass

import pytest

from marketlens.human.portfolio.preview import PortfolioAction
from marketlens.validation.account_capacity import (
    AccountProfile,
    ValidationConfig,
    canonical_price_matrix,
    deterministic_stress_paths,
    directional_capacity_rows,
    generate_monte_carlo_intents,
    run_deterministic_path,
)

ASSETS = ("CGEI", "CPEI", "EREI", "FSEI", "IEEI", "MEI", "REEI", "TLEI", "TSEI", "TTEI")
DATES = (
    "2023-06-19", "2023-06-20", "2023-06-21", "2023-06-26", "2023-06-27",
    "2023-06-28", "2023-06-29", "2023-06-30", "2023-07-03", "2023-07-04",
    "2023-07-05", "2023-07-06", "2023-07-07", "2023-07-10", "2023-07-11",
)

@dataclass(frozen=True)
class Close:
    close: float

class FakeProvider:
    def get_close(self, stock_id: str, date: str) -> Close:
        return Close(10.0 + ASSETS.index(stock_id) * 0.10 + DATES.index(date) * 0.02)

def profile(cash_fraction: float) -> AccountProfile:
    w = (1.0 - cash_fraction) / len(ASSETS)
    return AccountProfile(
        profile_id=f"c{cash_fraction}",
        total_wealth=1_000_000.0,
        cash_fraction=cash_fraction,
        initial_weights={a: w for a in ASSETS},
        max_position_weight=0.13,
        transaction_cost_bps=10.0,
    )

def cfg(p: AccountProfile) -> ValidationConfig:
    return ValidationConfig(
        total_wealth=p.total_wealth,
        target_stock_id="MEI",
        asset_ids=ASSETS,
        period_dates=DATES,
        critical_periods=frozenset({1, 8, 15}),
        family_id="test",
        family_description="test",
        profiles=(p,),
    )

def test_cash_probe_uses_distinct_assets_and_does_not_repeat_same_asset():
    p = profile(0.35)
    probe = deterministic_stress_paths(cfg(p))["same_period_6asset_buy5"]
    assert len(probe) == 6
    assert len({x.stock_id for x in probe}) == 6
    assert all(x.period_number == 1 for x in probe)
    assert all(x.action == PortfolioAction.BUY for x in probe)

def test_c35_is_locally_more_directionally_symmetric_than_c30_or_c40():
    matrix = canonical_price_matrix(FakeProvider(), asset_ids=ASSETS, period_dates=DATES)
    gaps = {}
    for cash in (0.30, 0.35, 0.40):
        p = profile(cash)
        rows = directional_capacity_rows(
            profile=p,
            episode_id="e",
            first_prices=matrix[DATES[0]],
            config=cfg(p),
        )
        gaps[cash] = sum(r["directional_gap_abs_pp"] for r in rows) / len(rows)
    assert gaps[0.35] < gaps[0.30]
    assert gaps[0.35] < gaps[0.40]

def test_monte_carlo_abstract_asset_delta_stays_within_plus_minus_five_points():
    p = profile(0.35)
    paths = generate_monte_carlo_intents(config=cfg(p), n_paths=25, seed=20260907)
    for _, intents in paths:
        delta = {a: 0.0 for a in ASSETS}
        for x in intents:
            delta[x.stock_id] += x.portfolio_fraction if x.action == PortfolioAction.BUY else -x.portfolio_fraction
            assert -0.0500000001 <= delta[x.stock_id] <= 0.0500000001

def test_passive_drift_metric_is_independent_of_participant_trade_path():
    p = profile(0.35)
    c = cfg(p)
    matrix = canonical_price_matrix(FakeProvider(), asset_ids=ASSETS, period_dates=DATES)
    hold, _ = run_deterministic_path(
        profile=p, episode_id="e", price_matrix=matrix, config=c,
        path_id="hold", intents=(),
    )
    traded, _ = run_deterministic_path(
        profile=p, episode_id="e", price_matrix=matrix, config=c,
        path_id="trade", intents=deterministic_stress_paths(c)["focal_increase_then_reversal"],
    )
    assert traded["passive_drift_max_abs_pp"] == pytest.approx(hold["passive_drift_max_abs_pp"])

def test_cash_failures_are_reported_separately_from_policy_failures():
    p = profile(0.25)
    c = cfg(p)
    matrix = canonical_price_matrix(FakeProvider(), asset_ids=ASSETS, period_dates=DATES)
    summary, _ = run_deterministic_path(
        profile=p,
        episode_id="e",
        price_matrix=matrix,
        config=c,
        path_id="cash-probe",
        intents=deterministic_stress_paths(c)["same_period_7asset_buy5"],
    )
    assert "critical_invalid_cash" in summary
    assert "critical_invalid_position_limit" in summary
    assert "critical_invalid_holdings" in summary
    assert "critical_cash_shortfall_sum" in summary
