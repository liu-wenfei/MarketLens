from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import importlib
import inspect
import json
import math
from pathlib import Path
import random
from typing import Iterable, Mapping, Sequence

from marketlens.human.portfolio.models import AccountState
from marketlens.human.portfolio.policy import PortfolioPolicy
from marketlens.human.portfolio.preview import PortfolioAction, PreviewReason, preview_order
from marketlens.human.portfolio.settlement import execute_preview


@dataclass(frozen=True)
class AccountProfile:
    profile_id: str
    total_wealth: float
    cash_fraction: float
    initial_weights: Mapping[str, float]
    max_position_weight: float | None
    transaction_cost_bps: float

    def policy(self) -> PortfolioPolicy:
        return PortfolioPolicy(
            transaction_cost_bps=self.transaction_cost_bps,
            max_position_weight=self.max_position_weight,
            whole_units=True,
            allow_short=False,
            allow_leverage=False,
        )


@dataclass(frozen=True)
class TradeIntent:
    period_number: int
    stock_id: str
    action: PortfolioAction
    portfolio_fraction: float
    label: str


@dataclass(frozen=True)
class ValidationConfig:
    total_wealth: float
    target_stock_id: str
    asset_ids: tuple[str, ...]
    period_dates: tuple[str, ...]
    critical_periods: frozenset[int]
    family_id: str
    family_description: str
    profiles: tuple[AccountProfile, ...]


def sha256_file(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def _strict_fraction(name: str, value: object) -> float:
    result = float(value)
    if not 0.0 <= result <= 1.0:
        raise ValueError(f"{name} must be in [0, 1]")
    return result


def load_validation_config(path: Path, *, family_id: str) -> ValidationConfig:
    payload = json.loads(path.read_text(encoding="utf-8"))
    total_wealth = float(payload["total_wealth"])
    if not math.isfinite(total_wealth) or total_wealth <= 0:
        raise ValueError("total_wealth must be positive and finite")

    asset_ids = tuple(str(x).strip() for x in payload["asset_ids"])
    if len(asset_ids) != len(set(asset_ids)) or not asset_ids:
        raise ValueError("asset_ids must be unique and non-empty")

    period_dates = tuple(str(x) for x in payload["period_dates"])
    if len(period_dates) != 15:
        raise ValueError("MarketLens account validation requires exactly 15 Period dates")

    target_stock_id = str(payload["target_stock_id"]).strip()
    if target_stock_id not in asset_ids:
        raise ValueError("target_stock_id must be in asset_ids")

    critical_periods = frozenset(int(x) for x in payload["critical_periods"])
    if not critical_periods.issubset(set(range(1, len(period_dates) + 1))):
        raise ValueError("critical_periods are outside the configured protocol")

    families = payload["families"]
    if family_id not in families:
        raise KeyError(f"Unknown candidate family {family_id!r}; available={sorted(families)}")
    family = families[family_id]

    profiles: list[AccountProfile] = []
    for raw in family["profiles"]:
        cash_fraction = _strict_fraction("cash_fraction", raw["cash_fraction"])
        if "initial_weights" in raw:
            weights = {str(k): float(v) for k, v in raw["initial_weights"].items()}
        else:
            per_asset = float(raw.get("initial_weight_per_asset", (1.0 - cash_fraction) / len(asset_ids)))
            weights = {stock_id: per_asset for stock_id in asset_ids}

        missing = set(asset_ids) - set(weights)
        extra = set(weights) - set(asset_ids)
        if missing or extra:
            raise ValueError(f"{raw['profile_id']}: initial weight asset mismatch; missing={missing}, extra={extra}")

        weight_sum = sum(weights.values())
        if abs(weight_sum - (1.0 - cash_fraction)) > 1e-9:
            raise ValueError(
                f"{raw['profile_id']}: risky weights sum to {weight_sum:.12f}, expected {1.0-cash_fraction:.12f}"
            )

        max_position_weight = raw.get("max_position_weight")
        if max_position_weight is not None:
            max_position_weight = _strict_fraction("max_position_weight", max_position_weight)
            if any(weight > max_position_weight + 1e-12 for weight in weights.values()):
                raise ValueError(f"{raw['profile_id']}: initial weight exceeds position cap")

        profiles.append(
            AccountProfile(
                profile_id=str(raw["profile_id"]),
                total_wealth=total_wealth,
                cash_fraction=cash_fraction,
                initial_weights=weights,
                max_position_weight=max_position_weight,
                transaction_cost_bps=float(raw["transaction_cost_bps"]),
            )
        )

    return ValidationConfig(
        total_wealth=total_wealth,
        target_stock_id=target_stock_id,
        asset_ids=asset_ids,
        period_dates=period_dates,
        critical_periods=critical_periods,
        family_id=family_id,
        family_description=str(family.get("description", "")),
        profiles=tuple(profiles),
    )


def build_initial_account(profile: AccountProfile, prices: Mapping[str, float]) -> tuple[AccountState, dict[str, float]]:
    positions: dict[str, int] = {}
    invested = 0.0
    realized_weights: dict[str, float] = {}

    for stock_id, target_weight in profile.initial_weights.items():
        price = float(prices[stock_id])
        if not math.isfinite(price) or price <= 0:
            raise ValueError(f"Invalid initial price for {stock_id}: {price}")
        target_notional = profile.total_wealth * float(target_weight)
        quantity = math.floor(target_notional / price)
        if quantity > 0:
            positions[stock_id] = quantity
            invested += quantity * price
            realized_weights[stock_id] = (quantity * price) / profile.total_wealth
        else:
            realized_weights[stock_id] = 0.0

    cash = round(profile.total_wealth - invested, 2)
    if cash < -1e-9:
        raise AssertionError("Initialisation produced negative cash")
    account = AccountState(cash=cash, positions=positions)
    return account, realized_weights


def _extract_close(value: object) -> float:
    if hasattr(value, "close"):
        value = getattr(value, "close")
    result = float(value)
    if not math.isfinite(result) or result <= 0:
        raise ValueError(f"Invalid canonical close price: {result}")
    return result


def canonical_price_matrix(
    provider: object,
    *,
    asset_ids: Sequence[str],
    period_dates: Sequence[str],
) -> dict[str, dict[str, float]]:
    matrix: dict[str, dict[str, float]] = {}
    for date in period_dates:
        matrix[date] = {
            stock_id: _extract_close(provider.get_close(stock_id, date))
            for stock_id in asset_ids
        }
    return matrix


def load_canonical_journey_price_providers(repo_root: Path) -> Mapping[str, object]:
    """Load the same canonical journey price-provider factory used by participant runtime.

    The current MarketLens test suite has used a one-root-argument factory. A few
    conservative invocation forms are supported here so that this offline tool does
    not force a runtime refactor if the parameter name changes.
    """
    module = importlib.import_module("marketlens.human.services.journey_provider_factory")
    factory = getattr(module, "build_canonical_journey_price_providers")
    signature = inspect.signature(factory)

    attempts: list[tuple[str, callable]] = [
        ("positional repo_root", lambda: factory(repo_root)),
        ("repo_root keyword", lambda: factory(repo_root=repo_root)),
        ("project_root keyword", lambda: factory(project_root=repo_root)),
        ("root keyword", lambda: factory(root=repo_root)),
    ]
    if not signature.parameters:
        attempts.append(("no arguments", lambda: factory()))

    errors: list[str] = []
    for label, attempt in attempts:
        try:
            providers = attempt()
        except TypeError as exc:
            errors.append(f"{label}: {exc}")
            continue
        if not isinstance(providers, Mapping) or not providers:
            raise RuntimeError("Canonical journey price-provider factory returned no episode providers")
        return providers

    raise RuntimeError(
        "Unable to call build_canonical_journey_price_providers with the supported root forms. "
        f"Signature={signature}; attempts={' | '.join(errors)}"
    )


def _weights(account: AccountState, prices: Mapping[str, float], asset_ids: Sequence[str]) -> dict[str, float]:
    total = account.total_value(prices)
    if total <= 0:
        return {stock_id: 0.0 for stock_id in asset_ids}
    return {
        stock_id: (int(account.positions.get(stock_id, 0)) * float(prices[stock_id])) / total
        for stock_id in asset_ids
    }


def deterministic_stress_paths(config: ValidationConfig) -> dict[str, tuple[TradeIntent, ...]]:
    """Policy-safe deterministic paths for cash-capacity comparison.

    These paths deliberately avoid repeatedly requesting more than the same
    asset can hold or sell. Hard position/holdings boundaries are tested
    separately from cash-capacity paths.
    """
    assets = list(config.asset_ids)
    target = config.target_stock_id
    others = [x for x in assets if x != target]

    def intent(period: int, stock_id: str, action: PortfolioAction, frac: float, label: str) -> TradeIntent:
        return TradeIntent(period, stock_id, action, frac, label)

    paths: dict[str, tuple[TradeIntent, ...]] = {"hold_all": ()}

    paths["focal_increase_then_reversal"] = (
        intent(1, target, PortfolioAction.BUY, 0.05, "P1 focal +5% PV"),
        intent(8, target, PortfolioAction.SELL, 0.05, "P8 focal -5% PV"),
        intent(15, target, PortfolioAction.SELL, 0.025, "P15 focal -2.5% PV"),
    )

    paths["focal_reduce_then_rebuild"] = (
        intent(1, target, PortfolioAction.SELL, 0.05, "P1 focal -5% PV"),
        intent(8, target, PortfolioAction.BUY, 0.05, "P8 focal +5% PV"),
        intent(15, target, PortfolioAction.BUY, 0.025, "P15 focal +2.5% PV"),
    )

    for k in (5, 6, 7):
        paths[f"same_period_{k}asset_buy5"] = tuple(
            intent(1, stock_id, PortfolioAction.BUY, 0.05, f"P1 distinct-asset BUY +5% #{idx}")
            for idx, stock_id in enumerate(assets[:k], start=1)
        )

    paths["same_period_multi_asset_rotation"] = (
        intent(8, others[0], PortfolioAction.SELL, 0.025, "rotation sell 1"),
        intent(8, others[1], PortfolioAction.SELL, 0.025, "rotation sell 2"),
        intent(8, others[2], PortfolioAction.SELL, 0.025, "rotation sell 3"),
        intent(8, others[3], PortfolioAction.BUY, 0.025, "rotation buy 1"),
        intent(8, others[4], PortfolioAction.BUY, 0.025, "rotation buy 2"),
        intent(8, others[5], PortfolioAction.BUY, 0.025, "rotation buy 3"),
    )

    paths["early_broad_sell_later_rebuild"] = tuple(
        [
            *[
                intent(1, stock_id, PortfolioAction.SELL, 0.025, "P1 broad sell -2.5%")
                for stock_id in assets[:5]
            ],
            *[
                intent(8, stock_id, PortfolioAction.BUY, 0.025, "P8 broad rebuild +2.5%")
                for stock_id in assets[:5]
            ],
        ]
    )

    paths["distributed_accumulation_then_unwind"] = (
        intent(1, assets[0], PortfolioAction.BUY, 0.05, "P1 +5%"),
        intent(2, assets[1], PortfolioAction.BUY, 0.05, "P2 +5%"),
        intent(3, assets[2], PortfolioAction.BUY, 0.05, "P3 +5%"),
        intent(4, assets[3], PortfolioAction.BUY, 0.05, "P4 +5%"),
        intent(8, assets[0], PortfolioAction.SELL, 0.05, "P8 unwind -5%"),
        intent(8, assets[1], PortfolioAction.SELL, 0.05, "P8 unwind -5%"),
    )

    paths["late_same_period_5asset_buy5"] = tuple(
        intent(15, stock_id, PortfolioAction.BUY, 0.05, f"P15 distinct-asset BUY +5% #{idx}")
        for idx, stock_id in enumerate(assets[5:10], start=1)
    )

    return paths

def passive_drift_max_abs_pp(
    *,
    profile: AccountProfile,
    price_matrix: Mapping[str, Mapping[str, float]],
    config: ValidationConfig,
) -> float:
    """Maximum weight drift under HOLD-only marking; participant trades excluded."""
    first_prices = price_matrix[config.period_dates[0]]
    account, realized_initial_weights = build_initial_account(profile, first_prices)
    maximum = 0.0
    for date in config.period_dates:
        weights = _weights(account, price_matrix[date], config.asset_ids)
        maximum = max(
            maximum,
            max(
                abs(weights[a] - realized_initial_weights.get(a, 0.0)) * 100.0
                for a in config.asset_ids
            ),
        )
    return maximum


def run_deterministic_path(
    *,
    profile: AccountProfile,
    episode_id: str,
    price_matrix: Mapping[str, Mapping[str, float]],
    config: ValidationConfig,
    path_id: str,
    intents: Sequence[TradeIntent],
) -> tuple[dict[str, object], list[dict[str, object]]]:
    first_prices = price_matrix[config.period_dates[0]]
    account, realized_initial_weights = build_initial_account(profile, first_prices)
    policy = profile.policy()
    initial_cash_fraction_realized = account.cash / profile.total_wealth
    initial_exposure_realized = 1.0 - initial_cash_fraction_realized
    min_cash_ratio = float("inf")
    max_position_weight_seen = 0.0
    passive_drift_pp = passive_drift_max_abs_pp(profile=profile, price_matrix=price_matrix, config=config)
    order_rows: list[dict[str, object]] = []
    intents_by_period: dict[int, list[TradeIntent]] = {}
    for intent in intents:
        intents_by_period.setdefault(intent.period_number, []).append(intent)

    for period_number, date in enumerate(config.period_dates, start=1):
        prices = price_matrix[date]
        for order_index, intent in enumerate(intents_by_period.get(period_number, ()), start=1):
            pv_before = account.total_value(prices)
            requested_amount = round(pv_before * intent.portfolio_fraction, 2)
            preview = preview_order(
                account=account,
                stock_id=intent.stock_id,
                action=intent.action,
                requested_amount=requested_amount,
                price=prices[intent.stock_id],
                prices=prices,
                policy=policy,
            )
            valid = bool(preview.valid)
            max_valid = preview.maximum_valid_amount
            if valid:
                account = execute_preview(account, preview)
            executable_amount = float(preview.executed_notional) if valid else 0.0
            if valid:
                shortfall_fraction = 0.0
            elif max_valid is None:
                shortfall_fraction = 1.0
            else:
                shortfall_fraction = max(0.0, 1.0 - min(float(max_valid), requested_amount) / requested_amount)

            order_rows.append(
                {
                    "family_id": config.family_id,
                    "profile_id": profile.profile_id,
                    "episode_id": episode_id,
                    "path_id": path_id,
                    "period_number": period_number,
                    "date": date,
                    "order_index": order_index,
                    "critical_period": period_number in config.critical_periods,
                    "label": intent.label,
                    "stock_id": intent.stock_id,
                    "action": intent.action.value,
                    "requested_portfolio_fraction": intent.portfolio_fraction,
                    "requested_amount": requested_amount,
                    "valid": valid,
                    "reason_code": preview.reason_code.value,
                    "maximum_valid_amount": max_valid,
                    "shortfall_fraction": shortfall_fraction,
                    "executed_units": int(preview.executable_units),
                    "executed_notional": executable_amount,
                    "fee": float(preview.fee),
                    "cash_before": float(preview.cash_before),
                    "cash_after": float(account.cash),
                    "holding_before": int(preview.holding_before),
                    "holding_after": int(account.positions.get(intent.stock_id, 0)),
                    "portfolio_value_before": float(preview.portfolio_value_before),
                    "portfolio_value_after": float(account.total_value(prices)),
                    "weight_before": float(preview.weight_before),
                    "weight_after": float(_weights(account, prices, config.asset_ids)[intent.stock_id]),
                }
            )

        period_total = account.total_value(prices)
        cash_ratio = (account.cash / period_total) if period_total > 0 else 0.0
        min_cash_ratio = min(min_cash_ratio, cash_ratio)
        weights = _weights(account, prices, config.asset_ids)
        max_position_weight_seen = max(max_position_weight_seen, max(weights.values(), default=0.0))

    invalid_rows = [row for row in order_rows if not row["valid"]]
    critical_invalid = [row for row in invalid_rows if row["critical_period"]]
    critical_shortfall = sum(float(row["shortfall_fraction"]) for row in critical_invalid)
    reason_counts = {reason.value: 0 for reason in PreviewReason}
    critical_reason_counts = {reason.value: 0 for reason in PreviewReason}
    for row in invalid_rows:
        reason_counts[str(row["reason_code"])] += 1
        if row["critical_period"]:
            critical_reason_counts[str(row["reason_code"])] += 1
    cash_shortfall_sum = sum(
        float(row["shortfall_fraction"])
        for row in invalid_rows
        if row["reason_code"] == PreviewReason.INSUFFICIENT_CASH.value
    )
    critical_cash_shortfall_sum = sum(
        float(row["shortfall_fraction"])
        for row in critical_invalid
        if row["reason_code"] == PreviewReason.INSUFFICIENT_CASH.value
    )

    final_prices = price_matrix[config.period_dates[-1]]
    summary = {
        "family_id": config.family_id,
        "profile_id": profile.profile_id,
        "cash_fraction_target": profile.cash_fraction,
        "max_position_weight": profile.max_position_weight,
        "transaction_cost_bps": profile.transaction_cost_bps,
        "episode_id": episode_id,
        "path_id": path_id,
        "initial_cash_fraction_realized": initial_cash_fraction_realized,
        "initial_market_exposure_realized": initial_exposure_realized,
        "orders_requested": len(order_rows),
        "orders_executed": sum(1 for row in order_rows if row["valid"]),
        "invalid_orders": len(invalid_rows),
        "invalid_cash": reason_counts[PreviewReason.INSUFFICIENT_CASH.value],
        "invalid_holdings": reason_counts[PreviewReason.INSUFFICIENT_HOLDINGS.value],
        "invalid_position_limit": reason_counts[PreviewReason.POSITION_LIMIT.value],
        "invalid_below_one_unit": reason_counts[PreviewReason.BELOW_ONE_UNIT.value],
        "critical_invalid_orders": len(critical_invalid),
        "critical_invalid_cash": critical_reason_counts[PreviewReason.INSUFFICIENT_CASH.value],
        "critical_invalid_holdings": critical_reason_counts[PreviewReason.INSUFFICIENT_HOLDINGS.value],
        "critical_invalid_position_limit": critical_reason_counts[PreviewReason.POSITION_LIMIT.value],
        "critical_shortfall_sum": critical_shortfall,
        "cash_shortfall_sum": cash_shortfall_sum,
        "critical_cash_shortfall_sum": critical_cash_shortfall_sum,
        "min_cash_ratio": min_cash_ratio if min_cash_ratio != float("inf") else initial_cash_fraction_realized,
        "max_position_weight_seen": max_position_weight_seen,
        "passive_drift_max_abs_pp": passive_drift_pp,
        "final_cash": float(account.cash),
        "final_total_value": float(account.total_value(final_prices)),
    }
    return summary, order_rows


def _safe_max_buy_amount(
    *, account: AccountState, stock_id: str, prices: Mapping[str, float], policy: PortfolioPolicy
) -> float:
    probe_amount = max(account.total_value(prices) * 10.0, float(prices[stock_id]))
    probe = preview_order(
        account=account,
        stock_id=stock_id,
        action=PortfolioAction.BUY,
        requested_amount=probe_amount,
        price=prices[stock_id],
        prices=prices,
        policy=policy,
    )
    if probe.valid:
        return float(probe.executed_notional)
    if probe.maximum_valid_amount is None:
        return 0.0
    return max(0.0, float(probe.maximum_valid_amount))


def _execute_near_capacity(
    *, account: AccountState, stock_id: str, prices: Mapping[str, float], policy: PortfolioPolicy
) -> tuple[AccountState, float, str]:
    maximum = _safe_max_buy_amount(account=account, stock_id=stock_id, prices=prices, policy=policy)
    price = float(prices[stock_id])
    if maximum < price:
        return account, 0.0, "BELOW_ONE_UNIT"

    # Use only the public preview/settlement contract. Step down conservatively if
    # continuous max amount lands just above an executable whole-unit boundary.
    amount = maximum
    for _ in range(8):
        preview = preview_order(
            account=account,
            stock_id=stock_id,
            action=PortfolioAction.BUY,
            requested_amount=amount,
            price=price,
            prices=prices,
            policy=policy,
        )
        if preview.valid:
            return execute_preview(account, preview), float(preview.executed_notional), preview.reason_code.value
        amount = max(0.0, amount - price)
        if amount < price:
            break
    return account, 0.0, "NO_EXECUTABLE_CAPACITY"


def boundary_search(
    *,
    profile: AccountProfile,
    episode_id: str,
    first_prices: Mapping[str, float],
    config: ValidationConfig,
) -> list[dict[str, object]]:
    policy = profile.policy()
    asset_orders: list[tuple[str, tuple[str, ...]]] = [
        ("alphabetical", tuple(sorted(config.asset_ids))),
        ("reverse", tuple(reversed(sorted(config.asset_ids)))),
        ("target_first", (config.target_stock_id,) + tuple(x for x in config.asset_ids if x != config.target_stock_id)),
        ("target_last", tuple(x for x in config.asset_ids if x != config.target_stock_id) + (config.target_stock_id,)),
    ]
    rows: list[dict[str, object]] = []

    base_account, _ = build_initial_account(profile, first_prices)
    initial_total = base_account.total_value(first_prices)
    initial_sell_capacity = sum(
        int(base_account.positions.get(stock_id, 0)) * float(first_prices[stock_id])
        for stock_id in config.asset_ids
    )

    for order_id, asset_order in asset_orders:
        account = base_account.copy()
        bought = 0.0
        for stock_id in asset_order:
            account, executed, _ = _execute_near_capacity(
                account=account,
                stock_id=stock_id,
                prices=first_prices,
                policy=policy,
            )
            bought += executed
        final_total = account.total_value(first_prices)
        rows.append(
            {
                "family_id": config.family_id,
                "profile_id": profile.profile_id,
                "episode_id": episode_id,
                "asset_order": order_id,
                "initial_total_value": initial_total,
                "upward_capacity_notional": bought,
                "upward_capacity_fraction": bought / initial_total if initial_total else 0.0,
                "downward_capacity_notional": initial_sell_capacity,
                "downward_capacity_fraction": initial_sell_capacity / initial_total if initial_total else 0.0,
                "directional_asymmetry_abs_fraction": abs(bought - initial_sell_capacity) / initial_total if initial_total else 0.0,
                "ending_cash_ratio": account.cash / final_total if final_total else 0.0,
            }
        )
    return rows


def directional_capacity_rows(
    *,
    profile: AccountProfile,
    episode_id: str,
    first_prices: Mapping[str, float],
    config: ValidationConfig,
) -> list[dict[str, object]]:
    """Per-asset initial up/down adjustment capacity using the real engine."""
    policy = profile.policy()
    base_account, _ = build_initial_account(profile, first_prices)
    total = base_account.total_value(first_prices)
    rows: list[dict[str, object]] = []

    for stock_id in config.asset_ids:
        current_notional = int(base_account.positions.get(stock_id, 0)) * float(first_prices[stock_id])
        downward_fraction = current_notional / total if total else 0.0
        upward_notional = _safe_max_buy_amount(
            account=base_account,
            stock_id=stock_id,
            prices=first_prices,
            policy=policy,
        )
        upward_fraction = upward_notional / total if total else 0.0
        rows.append(
            {
                "family_id": config.family_id,
                "profile_id": profile.profile_id,
                "episode_id": episode_id,
                "stock_id": stock_id,
                "initial_weight": downward_fraction,
                "upward_capacity_fraction": upward_fraction,
                "downward_capacity_fraction": downward_fraction,
                "directional_gap_abs_fraction": abs(upward_fraction - downward_fraction),
                "directional_gap_abs_pp": abs(upward_fraction - downward_fraction) * 100.0,
            }
        )
    return rows


def generate_monte_carlo_intents(
    *, config: ValidationConfig, n_paths: int, seed: int
) -> list[tuple[str, tuple[TradeIntent, ...]]]:
    """Generate bounded stress inputs, not a participant behaviour model."""
    rng = random.Random(seed)
    steps = (0.025, 0.05)
    bound = 0.05
    paths: list[tuple[str, tuple[TradeIntent, ...]]] = []

    for idx in range(n_paths):
        intents: list[TradeIntent] = []
        delta = {stock_id: 0.0 for stock_id in config.asset_ids}

        for period in range(1, len(config.period_dates) + 1):
            order_count = rng.randint(0, 3)
            for order_idx in range(order_count):
                candidates: list[tuple[str, PortfolioAction, float]] = []
                for stock_id in config.asset_ids:
                    for step in steps:
                        if delta[stock_id] + step <= bound + 1e-12:
                            candidates.append((stock_id, PortfolioAction.BUY, step))
                        if delta[stock_id] - step >= -bound - 1e-12:
                            candidates.append((stock_id, PortfolioAction.SELL, step))

                if not candidates:
                    break

                stock_id, action, step = rng.choice(candidates)
                intents.append(
                    TradeIntent(
                        period_number=period,
                        stock_id=stock_id,
                        action=action,
                        portfolio_fraction=step,
                        label=f"MC bounded stress input {order_idx + 1}",
                    )
                )
                delta[stock_id] += step if action == PortfolioAction.BUY else -step

        paths.append((f"mc-{idx:05d}", tuple(intents)))

    return paths


def monte_carlo_profile_summary(
    *,
    profile: AccountProfile,
    episode_id: str,
    price_matrix: Mapping[str, Mapping[str, float]],
    config: ValidationConfig,
    paths: Sequence[tuple[str, Sequence[TradeIntent]]],
) -> dict[str, object]:
    invalid_rates: list[float] = []
    cash_invalid_rates: list[float] = []
    holdings_invalid_rates: list[float] = []
    position_invalid_rates: list[float] = []
    critical_invalid_rates: list[float] = []
    critical_cash_invalid_rates: list[float] = []
    min_cash_ratios: list[float] = []
    critical_cash_shortfalls: list[float] = []

    for path_id, intents in paths:
        summary, _ = run_deterministic_path(
            profile=profile,
            episode_id=episode_id,
            price_matrix=price_matrix,
            config=config,
            path_id=path_id,
            intents=intents,
        )
        requested = int(summary["orders_requested"])
        invalid_rates.append(float(summary["invalid_orders"]) / requested if requested else 0.0)
        cash_invalid_rates.append(float(summary["invalid_cash"]) / requested if requested else 0.0)
        holdings_invalid_rates.append(float(summary["invalid_holdings"]) / requested if requested else 0.0)
        position_invalid_rates.append(float(summary["invalid_position_limit"]) / requested if requested else 0.0)

        critical_requested = sum(1 for intent in intents if intent.period_number in config.critical_periods)
        critical_invalid_rates.append(
            float(summary["critical_invalid_orders"]) / critical_requested if critical_requested else 0.0
        )
        critical_cash_invalid_rates.append(
            float(summary["critical_invalid_cash"]) / critical_requested if critical_requested else 0.0
        )
        min_cash_ratios.append(float(summary["min_cash_ratio"]))
        critical_cash_shortfalls.append(float(summary["critical_cash_shortfall_sum"]))

    def quantile(values: Sequence[float], q: float) -> float:
        if not values:
            return 0.0
        ordered = sorted(values)
        index = int(round((len(ordered) - 1) * q))
        return ordered[index]

    def mean(values: Sequence[float]) -> float:
        return sum(values) / len(values) if values else 0.0

    return {
        "family_id": config.family_id,
        "profile_id": profile.profile_id,
        "episode_id": episode_id,
        "monte_carlo_paths": len(paths),
        "mean_invalid_order_rate": mean(invalid_rates),
        "mean_cash_invalid_rate": mean(cash_invalid_rates),
        "mean_holdings_invalid_rate": mean(holdings_invalid_rates),
        "mean_position_invalid_rate": mean(position_invalid_rates),
        "mean_critical_invalid_rate": mean(critical_invalid_rates),
        "mean_critical_cash_invalid_rate": mean(critical_cash_invalid_rates),
        "mean_critical_cash_shortfall_sum": mean(critical_cash_shortfalls),
        "median_min_cash_ratio": quantile(min_cash_ratios, 0.50),
        "p05_min_cash_ratio": quantile(min_cash_ratios, 0.05),
        "p01_min_cash_ratio": quantile(min_cash_ratios, 0.01),
    }

