#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
from typing import Iterable, Mapping

# Allow this validation CLI to be executed directly from the repository root
# without requiring an external PYTHONPATH setting.
REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from marketlens.validation.account_capacity import (
    boundary_search,
    canonical_price_matrix,
    deterministic_stress_paths,
    directional_capacity_rows,
    generate_monte_carlo_intents,
    load_canonical_journey_price_providers,
    load_validation_config,
    monte_carlo_profile_summary,
    run_deterministic_path,
    sha256_file,
)


def _write_csv(path: Path, rows: Iterable[Mapping[str, object]]) -> None:
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _git(repo_root: Path, *args: str) -> str | None:
    try:
        result = subprocess.run(
            ["git", *args], cwd=repo_root, check=True, text=True, capture_output=True
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    return result.stdout.strip()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Offline MarketLens 15-Period participant account capacity validation."
    )
    parser.add_argument("--repo-root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("config/account_capacity_candidates_v1.json"),
    )
    parser.add_argument("--family", default="cash_sweep_cap13_fee10_v1")
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts/account_capacity_validation"))
    parser.add_argument("--monte-carlo", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260907)
    args = parser.parse_args()

    repo_root = args.repo_root.resolve()
    config_path = args.config if args.config.is_absolute() else repo_root / args.config
    output_dir = args.output_dir if args.output_dir.is_absolute() else repo_root / args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    config = load_validation_config(config_path, family_id=args.family)
    providers = load_canonical_journey_price_providers(repo_root)
    stress_paths = deterministic_stress_paths(config)
    mc_paths = generate_monte_carlo_intents(config=config, n_paths=max(args.monte_carlo, 0), seed=args.seed)

    summaries: list[dict[str, object]] = []
    orders: list[dict[str, object]] = []
    boundaries: list[dict[str, object]] = []
    directional: list[dict[str, object]] = []
    monte_carlo: list[dict[str, object]] = []
    episode_price_hashes: dict[str, str] = {}

    for episode_id, provider in sorted(providers.items()):
        matrix = canonical_price_matrix(
            provider,
            asset_ids=config.asset_ids,
            period_dates=config.period_dates,
        )
        matrix_bytes = json.dumps(matrix, sort_keys=True, separators=(",", ":")).encode("utf-8")
        import hashlib
        episode_price_hashes[str(episode_id)] = hashlib.sha256(matrix_bytes).hexdigest()

        for profile in config.profiles:
            for path_id, intents in stress_paths.items():
                summary, order_rows = run_deterministic_path(
                    profile=profile,
                    episode_id=str(episode_id),
                    price_matrix=matrix,
                    config=config,
                    path_id=path_id,
                    intents=intents,
                )
                summaries.append(summary)
                orders.extend(order_rows)

            boundaries.extend(
                boundary_search(
                    profile=profile,
                    episode_id=str(episode_id),
                    first_prices=matrix[config.period_dates[0]],
                    config=config,
                )
            )

            directional.extend(
                directional_capacity_rows(
                    profile=profile,
                    episode_id=str(episode_id),
                    first_prices=matrix[config.period_dates[0]],
                    config=config,
                )
            )

            if mc_paths:
                monte_carlo.append(
                    monte_carlo_profile_summary(
                        profile=profile,
                        episode_id=str(episode_id),
                        price_matrix=matrix,
                        config=config,
                        paths=mc_paths,
                    )
                )

    _write_csv(output_dir / "deterministic_summary.csv", summaries)
    _write_csv(output_dir / "deterministic_orders.csv", orders)
    _write_csv(output_dir / "boundary_search.csv", boundaries)
    _write_csv(output_dir / "directional_capacity.csv", directional)
    _write_csv(output_dir / "monte_carlo_summary.csv", monte_carlo)

    manifest = {
        "schema_version": "1.1",
        "validation_method_version": "marketlens-account-capacity-v2",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "family_id": config.family_id,
        "family_description": config.family_description,
        "config_path": str(config_path.relative_to(repo_root) if config_path.is_relative_to(repo_root) else config_path),
        "config_sha256": sha256_file(config_path),
        "runner_sha256": sha256_file(Path(__file__).resolve()),
        "git_branch": _git(repo_root, "branch", "--show-current"),
        "git_head": _git(repo_root, "rev-parse", "HEAD"),
        "git_status_porcelain": _git(repo_root, "status", "--porcelain"),
        "period_dates": list(config.period_dates),
        "critical_periods": sorted(config.critical_periods),
        "asset_ids": list(config.asset_ids),
        "target_stock_id": config.target_stock_id,
        "episode_ids": sorted(str(x) for x in providers),
        "episode_price_matrix_sha256": episode_price_hashes,
        "deterministic_path_ids": sorted(stress_paths),
        "monte_carlo_paths": len(mc_paths),
        "monte_carlo_seed": args.seed,
        "interpretation_note": (
            "Monte Carlo paths are bounded stress inputs over a predefined common action space; "
            "they are not a model or estimate of student behaviour. Selection metrics separate "
            "cash interference from position-cap and holdings constraints."
        ),
        "monte_carlo_action_space": {
            "per_asset_abstract_delta_bound": 0.05,
            "step_fractions": [0.025, 0.05],
            "orders_per_period": "uniform integer 0..3",
        },
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8"
    )

    print(f"PASS: account-capacity validation completed for family={config.family_id}")
    print(f"episodes={len(providers)} profiles={len(config.profiles)} deterministic_paths={len(stress_paths)} mc_paths={len(mc_paths)}")
    print(f"output_dir={output_dir}")
    print("files:")
    for name in (
        "deterministic_summary.csv",
        "deterministic_orders.csv",
        "boundary_search.csv",
        "directional_capacity.csv",
        "monte_carlo_summary.csv",
        "manifest.json",
    ):
        print(f"  {output_dir / name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
